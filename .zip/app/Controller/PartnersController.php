<?php

App::uses('ImplementableController', 'Implementable.Controller');

class PartnersController extends ImplementableController
{


}
