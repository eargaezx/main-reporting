<?php

App::uses('ImplementableController', 'Implementable.Controller');

class SubcontractorLicensesController extends ImplementableController
{


}
