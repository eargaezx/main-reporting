<?php

final class Input {
 
    
   

}
